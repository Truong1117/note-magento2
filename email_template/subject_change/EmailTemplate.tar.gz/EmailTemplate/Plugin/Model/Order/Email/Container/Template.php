<?php

namespace Commercers\EmailTemplate\Plugin\Model\Order\Email\Container;

class Template
{
    public function beforeSetTemplateVars(\Magento\Sales\Model\Order\Email\Container\Template $subject, array $vars)
    {
        /** @var Order $order */
        $order = $vars['order'];
        $method = $order->getShippingMethod();

        $vars['is_pickup'] = $method === 'freeshipping_freeshipping';

        return [$vars];
    }
}